import collections as c
import optparse


        
def main():
    p = optparse.OptionParser(__doc__)
    p.add_option("--tped", dest="tped", help="input file in .tped plink format", default=False, type='str')    
    p.add_option("--frq", dest="frq", help="input file in .frq plink format", default=False, type='str')    
    opts, args = p.parse_args()
   
    counts = []

    print "Please wait while counting genotypes frequences..."
    with open( str( opts.tped ) ) as ftped, open( opts.frq ) as freq:
        freq.readline() #first line contains headers
        for snp in ftped:
            snp_arr =  snp.rstrip().split( "\t" )
            cc = c.Counter( snp_arr[4:] )
            a1 , a2 = [ str(x) for x in freq.readline().split()[2:4] ]
            count  = str( snp_arr[1] ) + "\t"            
            count += str( cc[a2 + " " + a2] ) + "\t"            
            count += str( cc[a1 + " " + a2] + cc[a2 + " " + a1] ) + "\t"
            count += str( cc[a1 + " " + a1] ) + "\t"
            count += str( cc["0 0"] ) + "\n"
            counts.append( count )
            
    print "Writing the results on " + opts.tped + ".genoCounts"          
    with open( str(opts.tped) + ".genoCounts","w") as f:
        for count in counts:
            f.write( count )



if __name__ == "__main__":
    main()