print("Merge GWAS results. Please wait while processing")

if("optparse" %in% rownames(installed.packages()) == F){
  print("Attempting to install dependencies...")
  install.packages("optparse")  
}

require(optparse)

#options
option_list = list(
  make_option(c("--dir"), type="character", default=NULL, help="path of the directory containing the files!", metavar="character")
)
opt_parser = OptionParser(option_list=option_list)
opt = parse_args(opt_parser)

#
setwd(opt$dir)
print("All dependecies are satisfied")
print("Merge GWAS results. Please wait while processing")


# read GWAS results
gwas_cov_pca.assoc =  read.table(file = "gwas_cov_pca.assoc.linear", header = T, stringsAsFactors = F)

# choose only the additive test
gwas_cov_pca.assoc =  gwas_cov_pca.assoc[gwas_cov_pca.assoc$TEST == 'ADD', -c(4)]

# read statistics files 
malaria_senegal_clean.frq =  read.table(file = "malaria_senegal_clean.frq", header = T, stringsAsFactors = F)

malaria_senegal_clean.frq = malaria_senegal_clean.frq[,c('SNP','A2', 'A1','MAF')] # [ NEW ]
colnames(malaria_senegal_clean.frq) = c('SNP','A1', 'A2','MAF') # [ NEW ]

malaria_senegal_clean.hwe =  read.table(file = "malaria_senegal_clean.hwe", header = T, stringsAsFactors = F)
malaria_senegal_clean.imiss =  read.table(file = "malaria_senegal_clean.imiss", header = T, stringsAsFactors = F)
malaria_senegal_clean.lmiss =  read.table(file = "malaria_senegal_clean.lmiss", header = T, stringsAsFactors = F)

# read annotation file
malaria_senegal.annotation = read.table(file = "malaria_senegal_annovar.variant_function", header = F)
colnames(malaria_senegal.annotation)[c(1,2,8)] = c("REGION", "GENE", "SNP")

#
genoCounts =  read.table(file = "malaria_senegal_clean.tped.genoCounts", header = F) # [ NEW ]
colnames(genoCounts) = c("SNP","A1A1", "A1A2", "A2A2", "A0A0") # [ NEW ]

# choose both affected and unaffected = ALL
malaria_senegal_clean.hwe = malaria_senegal_clean.hwe[malaria_senegal_clean.hwe$TEST == 'ALL', ]



# merge tables
colnames(malaria_senegal_clean.hwe)[6:ncol(malaria_senegal_clean.hwe)] = paste0('HWE_',colnames(malaria_senegal_clean.hwe)[6:ncol(malaria_senegal_clean.hwe)])
colnames(malaria_senegal_clean.lmiss)[3:ncol(malaria_senegal_clean.lmiss)] = paste0('LOC_',colnames(malaria_senegal_clean.lmiss)[3:ncol(malaria_senegal_clean.lmiss)])

gwas_cov_pca.assoc.merge = merge(gwas_cov_pca.assoc,
                                 malaria_senegal.annotation[,c("REGION", "GENE", "SNP")],
                                 by='SNP', all.x=T)
gwas_cov_pca.assoc.merge = merge(gwas_cov_pca.assoc.merge , malaria_senegal_clean.frq, by='SNP')
gwas_cov_pca.assoc.merge = merge(gwas_cov_pca.assoc.merge,
                                 malaria_senegal_clean.hwe[,c('SNP',colnames(malaria_senegal_clean.hwe)[6:ncol(malaria_senegal_clean.hwe)])],
                                 by='SNP')
gwas_cov_pca.assoc.merge = merge(gwas_cov_pca.assoc.merge,
                                 malaria_senegal_clean.lmiss[,c('SNP',colnames(malaria_senegal_clean.lmiss)[3:ncol(malaria_senegal_clean.lmiss)])],
                                 by='SNP')

# [ NEW ]
gwas_cov_pca.assoc.merge = merge(gwas_cov_pca.assoc.merge,
                                 genoCounts,
                                 by='SNP')

# tri des P par ordre croissant
gwas_cov_pca.assoc.merge = gwas_cov_pca.assoc.merge[order(gwas_cov_pca.assoc.merge$P),]

# ecriture des resultats compiles
write.table(file = "gwas_cov_pca.assoc.linear.merge", x = gwas_cov_pca.assoc.merge, 
            col.names = T, row.names = F, quote = F, sep = "\t")

print("Results are written in file: 'gwas_cov_pca.assoc.linear.merge'")
print("Done. Bye!")